setInterval (function (){
  var w = document.getElementById('blk').offsetWidth;
	document.getElementById("blk").style.height = document.getElementById('blk').offsetWidth + 'px';
},200);